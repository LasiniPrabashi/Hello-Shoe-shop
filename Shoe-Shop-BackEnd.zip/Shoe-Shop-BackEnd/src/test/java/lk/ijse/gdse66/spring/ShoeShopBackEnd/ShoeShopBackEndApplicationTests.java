package lk.ijse.gdse66.spring.ShoeShopBackEnd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoeShopBackEndApplicationTests {

	@Test
	void contextLoads() {
	}

}
