package lk.ijse.gdse66.spring.ShoeShopBackEnd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoeShopBackEndApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoeShopBackEndApplication.class, args);
	}

}
